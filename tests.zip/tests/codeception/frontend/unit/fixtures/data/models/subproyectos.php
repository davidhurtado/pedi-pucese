<?php

return [
    [
        'id_proyecto' => 1,
        'nombre' => 'Sub-Proyecto 1',
        'descripcion' => 'Test Sub-Proyecto 1',
        'evidencias' => 'test_subproyecto1.pdf;',
        'fecha_inicio' => date('y-m-d'),
        'fecha_fin' => '2018-12-31',
    ],
     [
        'id_proyecto' => 1,
        'nombre' => 'Sub-Proyecto 2',
        'descripcion' => 'Test Sub-Proyecto 2',
        'evidencias' => 'test_subproyecto2.pdf;',
        'fecha_inicio' => date('y-m-d'),
        'fecha_fin' => '2016-12-31',
    ],
];
