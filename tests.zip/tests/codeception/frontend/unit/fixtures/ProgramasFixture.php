<?php

namespace tests\codeception\frontend\unit\fixtures;

use yii\test\ActiveFixture;

/**
 * User fixture
 */
class ProgramasFixture extends ActiveFixture
{
    public $modelClass = 'app\models\Programas';
}
