<?php

namespace tests\codeception\frontend\unit\fixtures;

use yii\test\ActiveFixture;

/**
 * User fixture
 */
class ObjetivosFixture extends ActiveFixture
{
    public $modelClass = 'app\models\Objetivos';
}
