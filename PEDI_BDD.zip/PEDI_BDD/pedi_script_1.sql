/*==============================================================*/
/* db name: pedi                                                */
/*==============================================================*/

/*==============================================================*/
/* tabla: objetivos                                             */
/*==============================================================*/
create table objetivos (
   id serial primary key,
   numeracion int not null unique,
   descripcion text  not null,
   responsable  int not null,
   colaboradores text not null,
   fecha_inicio date not null,
   fecha_fin date not null
);

/*==============================================================*/
/* tabla: estrategias                                           */
/*==============================================================*/
create table estrategias (
   id serial primary key,
   id_objetivo int not null,
   numeracion int not null unique,
   descripcion text not null,
   responsable  int not null,
   colaboradores text not null,
   fecha_inicio date not null,
   fecha_fin date not null,
   presupuesto numeric null
);

/*==============================================================*/
/* tabla: programas                                             */
/*==============================================================*/
create table programas (
   id serial primary key,
   id_estrategia int not null,
   numeracion int not null unique,
   descripcion text not null,
   responsable  int not null,
   colaboradores text not null,
   fecha_inicio date not null,
   fecha_fin date not null,
   presupuesto numeric null
);

/*==============================================================*/
/* tabla: proyectos                                             */
/*==============================================================*/
create table proyectos (
   id serial primary key,
   id_programa int not null,
   numeracion int not null unique,
   nombre text not null,
   descripcion text not null,
   responsable  int not null,
   colaboradores text not null,
   fecha_inicio date not null,
   fecha_fin date not null,
   presupuesto numeric null,
   estado int deafult 1
);
ALTER TABLE proyectos ADD constraint estado check (estado=1 or estado=2 or estado=3 or estado=4);

/*==============================================================*/
/* tabla: subproyectos                                          */
/*==============================================================*/
create table subproyectos (
   id serial primary key,
   id_proyecto int not null,
   numeracion int not null unique,
   fecha_inicio date not null,
   fecha_fin date not null,
   estado int null
);

/*==============================================================*/
/* tabla: actividades                                           */
/*==============================================================*/
create table actividades (
   id serial primary key,
   id_subproyecto int not null,
   numeracion int not null unique,
   descripcion text not null,
   codigo_presupuestario  char(10)not null,
   presupuesto numeric null,
   fecha_inicio date not null,
   fecha_fin date not null
);

--------------- mod - organigrama ----------------
create table organigrama (
    id serial not null primary key,
    name text,
   created date not null default current_date,
   activo int 
);
comment on table organigrama is 'organigrama general pedi';

create table niveles (
    nid serial not null primary key,
    title text,
    rid integer,
    org_id integer not null,
   constraint fk_levels_org foreign key (org_id) references organigrama (id)on delete cascade on update cascade,
   constraint fk_levels_rid foreign key (rid) references niveles (nid)on delete cascade on update cascade
);

comment on table niveles is 'niveles para organigrama';
create table poa (
   id serial primary key,
   fecha_creacion date not null default current_date,
   fecha_ejecucion date null,
   estado int not null default 1
);

create table poa_proyectos (
   id_poa int not null,
   id_proyecto int not null,
   primary key(id_poa, id_proyecto) 
);

alter table poa_proyectos add foreign key (id_poa) references poa(id) on delete cascade on update cascade;
alter table poa_proyectos add foreign key (id_proyecto) references proyectos(id) on delete cascade on update cascade;


alter table estrategias add foreign key (id_objetivo) references objetivos(id) on delete cascade on update cascade;
alter table programas add foreign key (id_estrategia) references estrategias(id)  on delete cascade on update cascade;
alter table proyectos add foreign key (id_programa) references programas(id)  on delete cascade on update cascade;
alter table subproyectos add foreign key (id_proyecto) references proyectos(id)  on delete cascade on update cascade;
alter table actividades add foreign key (id_subproyecto) references subproyectos(id)  on delete cascade on update cascade;
