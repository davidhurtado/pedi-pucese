/*==============================================================================================================================*/
/* 		      				         Triggers: Objetivos                                                    */
/*==============================================================================================================================*/
CREATE OR REPLACE FUNCTION organigrama_activo()
RETURNS TRIGGER AS $$
DECLARE
BEGIN
	IF NEW.activo=1 THEN
	UPDATE organigrama SET activo = 0  WHERE id!=NEW.id;
	END IF;
	RETURN NEW;
END;
$$
LANGUAGE 'plpgsql';

CREATE TRIGGER organigrama_activo AFTER INSERT OR UPDATE
	ON organigrama FOR EACH ROW
	EXECUTE PROCEDURE organigrama_activo();

CREATE OR REPLACE FUNCTION crear_subproyectos()
RETURNS TRIGGER AS $$
DECLARE
anio_ini int;
anio_fin int;
anio_total int;
x int;
BEGIN
	anio_ini:= (SELECT EXTRACT(YEAR FROM NEW.fecha_inicio));
	anio_fin:= (SELECT EXTRACT(YEAR FROM NEW.fecha_fin));
	anio_total:=anio_fin-anio_ini;
	if anio_total = 0 then
	INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,NEW.fecha_inicio,NEW.fecha_fin);
	RETURN NEW;
	end if;
	if anio_total = 1 then
		INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,NEW.fecha_inicio,to_date(concat(anio_ini,'-12-31'), 'yyyy-mm-dd'));
		INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,to_date(concat(anio_fin,'-01-01'), 'yyyy-mm-dd'),NEW.fecha_fin);
		RETURN NEW;
	else
		INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,NEW.fecha_inicio,to_date(concat(anio_ini,'-12-31'), 'yyyy-mm-dd'));
		CASE
		    WHEN anio_total BETWEEN 2 AND anio_total-1 THEN
		    anio_ini:=anio_ini+1;
		    anio_total:=anio_total-1;
		    INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,to_date(concat(anio_ini,'-02-01'), 'yyyy-mm-dd'),to_date(concat(anio_ini,'-12-31'), 'yyyy-mm-dd'));
		ELSE
		anio_ini:=anio_ini+1;
		INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,to_date(concat(anio_ini,'-03-01'), 'yyyy-mm-dd'),NEW.fecha_fin);
		END CASE;
		
		RETURN NEW;
	end if;
END;
$$
LANGUAGE 'plpgsql';

CREATE TRIGGER crear_subproyectos AFTER INSERT OR UPDATE
	ON proyectos FOR EACH ROW
	EXECUTE PROCEDURE crear_subproyectos();


ALTER TABLE public.subproyectos ADD COLUMN estado integer;
ALTER TABLE public.proyectos ADD COLUMN estado integer DEFAULT 1;


INSERT INTO proyectos VALUES (2, '2', '2', '6', '2018-10-25', '2019-07-12', NULL, 17) 
