<?php

return [
    [
        'id_programa' => 1,
        'nombre' => 'Proyecto 1',
        'descripcion' => 'Test Proyecto 1',
        'responsables' => '2,4,6',
        'fecha_inicio' => date('y-m-d'),
        'fecha_fin' => '2017-12-31',
        'presupuesto' => 4100,
    ],
     [
        'id_programa' => 2,
        'nombre' => 'Proyecto 2',
        'descripcion' => 'Test Proyecto 2',
        'responsables' => '10,12',
        'fecha_inicio' => date('y-m-d'),
        'fecha_fin' => '2016-12-31',
        'presupuesto' => 4200,
    ],
];
