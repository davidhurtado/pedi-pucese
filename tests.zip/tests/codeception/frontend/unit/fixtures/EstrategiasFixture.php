<?php

namespace tests\codeception\frontend\unit\fixtures;

use yii\test\ActiveFixture;

/**
 * User fixture
 */
class EstrategiasFixture extends ActiveFixture
{
    public $modelClass = 'app\models\Estrategias';
}
