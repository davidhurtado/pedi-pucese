<?php

return [
    [   // id ->1
        'descripcion' => 'Unit test Fixture 1',
        'responsables' => '1,3,5',
        'fecha_inicio' => date('Y-m-d'),
        'fecha_fin' => '2020-12-31',
    ],
    [   // id ->2
        'descripcion' => 'Unit test Fixture 2',
        'responsables' => '4,7,8',
        'fecha_inicio' => date('Y-m-d'),
        'fecha_fin' => '2022-12-31',
    ],
    [   // id ->3
        'descripcion' => 'Unit test Fixture 3',
        'responsables' => '3,4,8,9',
        'fecha_inicio' => date('Y-m-d'),
        'fecha_fin' => '2025-12-31',
    ],
];
