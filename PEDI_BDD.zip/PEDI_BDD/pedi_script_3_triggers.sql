/*==============================================================================================================================*/
/* 		      				         Triggers: Objetivos                                                    */
/*==============================================================================================================================*/
CREATE OR REPLACE FUNCTION organigrama_activo()
RETURNS TRIGGER AS $$
DECLARE
BEGIN
	IF NEW.activo=1 THEN
	UPDATE organigrama SET activo = 0  WHERE id!=NEW.id;
	END IF;
	RETURN NEW;
END;
$$
LANGUAGE 'plpgsql';

CREATE TRIGGER organigrama_activo AFTER INSERT OR UPDATE
	ON organigrama FOR EACH ROW
	EXECUTE PROCEDURE organigrama_activo();
/*==============================================================================================================================*/
/* 		      				         Triggers: agregar Proyectos al POA                                     */
/*==============================================================================================================================*/
CREATE OR REPLACE FUNCTION agregar_proyecto_a_poa()
RETURNS TRIGGER AS $$
DECLARE
fecha int;
idPoa int;
BEGIN
	fecha:=(SELECT EXTRACT(YEAR FROM NEW.fecha_inicio));
	select id into idPoa from poa where fecha_ejecucion=to_date(concat(fecha,'-01-01'), 'yyyy-mm-dd');
	insert into poa_proyectos(id_poa,id_proyecto) values(idPoa,NEW.id);
	RETURN NEW;
END;
$$
LANGUAGE 'plpgsql';

CREATE TRIGGER agregar_proyecto_a_poa AFTER INSERT
	ON proyectos FOR EACH ROW
	EXECUTE PROCEDURE agregar_proyecto_a_poa();

	update subproyectos set estado=1


CREATE OR REPLACE FUNCTION crear_subproyectos()
RETURNS TRIGGER AS $$
DECLARE
anio_ini int;
anio_fin int;
anio_total int;
x int;
y int;
r subproyectos%rowtype;
id_sub int;
BEGIN
	anio_ini:= (SELECT EXTRACT(YEAR FROM NEW.fecha_inicio));
	anio_fin:= (SELECT EXTRACT(YEAR FROM NEW.fecha_fin));
	anio_total:=anio_fin-anio_ini;
	if TG_OP = 'UPDATE' then
		if anio_total = 0 then
		UPDATE subproyectos set fecha_inicio=NEW.fecha_inicio,fecha_fin=NEW.fecha_fin where id_proyecto= NEW.id;
		id_sub:=(SELECT id FROM subproyectos WHERE id_proyecto= NEW.id order by id asc limit 1);
		delete from subproyectos where id_proyecto=NEW.id and id > id_sub;
		RETURN NEW;
		end if;

			x:=-1;
			
			 FOR r IN SELECT * FROM subproyectos WHERE id_proyecto= NEW.id order by id asc LOOP
				 if x=-1 then
					 UPDATE subproyectos set fecha_inicio=NEW.fecha_inicio,fecha_fin=to_date(concat(anio_ini,'-12-31'), 'yyyy-mm-dd') where id_proyecto= NEW.id and id=r.id;
					 x:=x+1;
				 else
					 anio_ini:=anio_ini+1;
					 UPDATE subproyectos set fecha_inicio= to_date(concat(anio_ini,'-01-01'), 'yyyy-mm-dd'),fecha_fin=to_date(concat(anio_ini,'-12-31'), 'yyyy-mm-dd')  where id_proyecto= NEW.id and id=r.id;
					 x:=x+1;
				 end if;
			 END LOOP;
			 if (anio_total - x) > 0 then
				 y:=0;
				 FOR y IN 1..(anio_total - x)-1 LOOP
				    anio_ini:=anio_ini+1;
				    INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,to_date(concat(anio_ini,'-01-01'), 'yyyy-mm-dd'),to_date(concat(anio_ini,'-12-31'), 'yyyy-mm-dd'));
				END LOOP;
				anio_ini:=anio_ini+1;
				INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,to_date(concat(anio_ini,'-01-01'), 'yyyy-mm-dd'),NEW.fecha_fin);
				RETURN NEW;
			end if;
			id_sub:=(SELECT id FROM subproyectos WHERE id_proyecto= NEW.id and fecha_inicio=to_date(concat(anio_fin,'-01-01'), 'yyyy-mm-dd') order by id asc limit 1);
			UPDATE subproyectos set fecha_inicio=to_date(concat(anio_fin,'-01-01'), 'yyyy-mm-dd'),fecha_fin=NEW.fecha_fin where id_proyecto= NEW.id and id=id_sub;
			delete from subproyectos where id_proyecto=NEW.id and id > id_sub;
			RETURN NEW;
		
	end if;
	if TG_OP = 'INSERT' then
		if anio_total = 0 then
		INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,NEW.fecha_inicio,NEW.fecha_fin);
		RETURN NEW;
		end if;
		if anio_total = 1 then
			INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,NEW.fecha_inicio,to_date(concat(anio_ini,'-12-31'), 'yyyy-mm-dd'));
			INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,to_date(concat(anio_fin,'-01-01'), 'yyyy-mm-dd'),NEW.fecha_fin);
			RETURN NEW;
		else
			x:=0;
			INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,NEW.fecha_inicio,to_date(concat(anio_ini,'-12-31'), 'yyyy-mm-dd'));
			FOR x IN 1..anio_total-1 LOOP
			    anio_ini:=anio_ini+1;
			    INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,to_date(concat(anio_ini,'-01-01'), 'yyyy-mm-dd'),to_date(concat(anio_ini,'-12-31'), 'yyyy-mm-dd'));
			END LOOP;
			anio_ini:=anio_ini+1;
			INSERT INTO subproyectos (id_proyecto,fecha_inicio,fecha_fin) values (NEW.id,to_date(concat(anio_ini,'-01-01'), 'yyyy-mm-dd'),NEW.fecha_fin);
			RETURN NEW;
		end if;
	end if;
	
END;
$$
LANGUAGE 'plpgsql';

/*==============================================================================================================================*/
/* 		      				         Triggers: estado_subproyecto                                                               */
/*==============================================================================================================================*/
CREATE TRIGGER crear_subproyectos AFTER INSERT OR UPDATE
	ON proyectos FOR EACH ROW
	EXECUTE PROCEDURE crear_subproyectos();

CREATE OR REPLACE FUNCTION actualizar_estado_subproyectos()
RETURNS TRIGGER AS $$
DECLARE
BEGIN
	UPDATE subproyectos set estado=NEW.estado where id_proyecto = NEW.id;
	RETURN NEW;
END;
$$
LANGUAGE 'plpgsql';

CREATE TRIGGER actualizar_estado_subproyectos AFTER UPDATE
	ON proyectos FOR EACH ROW
	EXECUTE PROCEDURE actualizar_estado_subproyectos();
/*==============================================================================================================================*/
/* 		      				         Triggers: estado_proyecto_desde_poa                                    */
/*==============================================================================================================================*/
CREATE OR REPLACE FUNCTION estado_proyecto_desde_poa()
RETURNS TRIGGER AS $$
DECLARE
r poa_proyectos%rowtype;
BEGIN
	IF NEW.estado=3 THEN
		FOR r IN SELECT * FROM poa_proyectos WHERE id_poa = NEW.id LOOP
			UPDATE proyectos set estado=4 where id=r.id_proyecto;
		END LOOP;
	END IF;
	IF NEW.estado=2 THEN
		FOR r IN SELECT * FROM poa_proyectos WHERE id_poa = NEW.id LOOP
			UPDATE proyectos set estado=3 where id=r.id_proyecto;
		END LOOP;
	END IF;
	IF NEW.estado=1 THEN
		FOR r IN SELECT * FROM poa_proyectos WHERE id_poa = NEW.id LOOP
			UPDATE proyectos set estado=2 where id=r.id_proyecto;
		END LOOP;
	END IF;
	RETURN NEW;
END;
$$
LANGUAGE 'plpgsql';

CREATE TRIGGER estado_proyecto_desde_poa AFTER UPDATE
	ON poa FOR EACH ROW
	EXECUTE PROCEDURE estado_proyecto_desde_poa();




ALTER TABLE public.subproyectos ADD COLUMN estado integer;
ALTER TABLE public.proyectos ADD COLUMN estado integer DEFAULT 1;
ALTER TABLE public.objetivos ADD COLUMN validacion integer DEFAULT 1;
ALTER TABLE public.estrategias ADD COLUMN validacion integer DEFAULT 1;
ALTER TABLE public.programas ADD COLUMN validacion integer DEFAULT 1;
ALTER TABLE public.proyectos ADD COLUMN validacion integer DEFAULT 1;
ALTER TABLE public.actividades ADD COLUMN validacion integer DEFAULT 1;

INSERT INTO proyectos VALUES (2, '2', '2', '6', '2018-10-25', '2019-07-12', NULL, 17) 
